# MEET.ONE Smart Contract Security Audit Report

## Summary

* Audit Date: Aug 01, 2018
* Audit Result: Passed(excellent)
* Audit Team: SlowMist Security Team
* Public Date: Aug 01, 2018

## Report

![Page1](report-images//0001.jpg)
![Page2](report-images//0002.jpg)
![Page3](report-images//0003.jpg)
![Page4](report-images//0004.jpg)
![Page5](report-images//0005.jpg)
![Page6](report-images//0006.jpg)
![Page7](report-images//0007.jpg)
![Page8](report-images//0008.jpg)
![Page9](report-images//0009.jpg)
![Page10](report-images//0010.jpg)
